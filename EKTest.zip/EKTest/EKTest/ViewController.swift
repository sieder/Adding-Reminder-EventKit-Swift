//
//  ViewController.swift
//  EKTest
//
//  Created by Sieder Villareal on 2/21/15.
//  Copyright (c) 2015 shaideru. All rights reserved.
//

import UIKit
import EventKit


class ViewController: UIViewController {

    
    @IBOutlet weak var reminderTitle: UITextField!
    @IBOutlet weak var reminderDatePicker: UIDatePicker!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        eventStoreAccessReminders()

        
    }

    @IBAction func setReminder(sender: AnyObject) {
        
        
        calendarDatabase.requestAccessToEntityType(EKEntityTypeReminder, completion: { (granted, error) -> Void in
            
            if !granted {
                println("Access to store not granted")
                println(error.localizedDescription)
            } else {
                println("Reminder entered: \(self.reminderTitle.text), \(self.reminderDatePicker.date)")
            }
            
        })  
        
        createReminder(reminderTitle.text, reminderDatePicker.date)

    }
    
    override func touchesBegan(touches: NSSet, withEvent event: UIEvent) {
        reminderTitle.endEditing(true)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

