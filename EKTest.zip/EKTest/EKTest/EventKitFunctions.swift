//
//  EventKitFunctions.swift
//  EKTest
//
//  Created by Sieder Villareal on 2/21/15.
//  Copyright (c) 2015 shaideru. All rights reserved.
//

import Foundation
import EventKitUI

var calendarDatabase = EKEventStore()

func eventStoreAccessReminders() {

    calendarDatabase.requestAccessToEntityType(EKEntityTypeReminder, completion: {(granted: Bool, error:NSError!) -> Void in
        if !granted {
            println("Access to store not granted")
        }
    })
    
}

func accessCalendarInTheDatabase() {
    var calendars = calendarDatabase.calendarsForEntityType(EKEntityTypeReminder)
    
    for calendar in calendars as [EKCalendar] {
        println("Calendar = \(calendar.title)")
    }
}

func createReminder(reminderTitle: String, reminderDate: NSDate) {
    let reminder = EKReminder(eventStore: calendarDatabase)
    
    reminder.title = reminderTitle
    let date = reminderDate
    let alarm = EKAlarm(absoluteDate: date)
    
    reminder.addAlarm(alarm)
    
    reminder.calendar = calendarDatabase.defaultCalendarForNewReminders()
    
    var error: NSError?
    
    if error != nil{
        println("errors: \(error?.localizedDescription)")
    }
    
    calendarDatabase.saveReminder(reminder, commit: true, error: &error)
}



